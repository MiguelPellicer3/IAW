// valor 1
alert("Empieza el ejercicio 1");
// Crea 2 variables numéricas
let num1 = 2;
let num2 = 458;

// Imprime un alert con la suma de ambas.
alert(num1 + num2);

// Imprime un alert con la resta de ambas.
alert(num1 - num2);

// Imprime un alert con el producto de ambas.
alert(num1 * num2);

// Cambia el valor de la segunda variable a 0.
num2 = 0;

// Imprime la division de ambas.
alert(num1 / num2);