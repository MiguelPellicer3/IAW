// valor 1
alert("Empieza el ejercicio 2");
// Crea una variable numérica.
let num = 0;

// Crea una cadena de texto con el valor 25.
let text = "25";

// Imprime la suma de ambas mediante un alert.
alert(num + text);

// Crea una variable booleana.
let booleana = true;

// Imprime en la consola la suma de las 3 variables.
console.log(num + text + booleana)